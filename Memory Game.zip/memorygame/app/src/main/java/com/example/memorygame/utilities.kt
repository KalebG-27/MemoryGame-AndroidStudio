package com.example.memorygame

val DEFFAULT_ICONS = listOf(
    R.drawable.ic_baseline_php_24,
    R.drawable.ic_bug,
    R.drawable.ic_flame,
    R.drawable.ic_flame2,
    R.drawable.ic_plane,
    R.drawable.ic_fingerprint,
    R.drawable.ic_baseline_cloud_queue_24,
    R.drawable.ic_snowflake,
    R.drawable.ic_warning,
    R.drawable.ic_baseline_two_wheeler_24,
    R.drawable.ic_baseline_vpn_key_24,
    R.drawable.ic_baseline_videogame_asset_24,


)
